"""Deterministic recommendation policies."""
